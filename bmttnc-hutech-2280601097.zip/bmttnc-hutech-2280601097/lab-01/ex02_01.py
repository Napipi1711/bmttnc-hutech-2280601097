ten = input("Input your ten:")
tuoi = input("Input your tuoi:")

print("Welcome,", ten, " ! bạn", tuoi, "tuổi")