print("Hello,World!")
print("MyNameIsHung")
print("Hutech University")