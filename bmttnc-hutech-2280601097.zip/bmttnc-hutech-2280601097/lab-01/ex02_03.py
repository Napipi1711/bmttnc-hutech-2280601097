so = int(input("Nhap so nguyen"))

if so % 2 == 0 : print(so, "la so chan")
else: 
    print(so,"khong phai so chan")