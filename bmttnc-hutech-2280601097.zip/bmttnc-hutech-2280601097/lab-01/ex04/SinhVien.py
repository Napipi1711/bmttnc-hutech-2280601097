class SinhVien:
    def __init__(self, id , name , sex, major, diemTB):
        self._id = id
        self._name = name
        self._sex = sex
        self._major = major
        self._diemTB = diemTB
        self._hocluc = ""