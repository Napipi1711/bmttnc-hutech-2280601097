ban_kinh = float(input("Nhap ban kinh " ))

dien_tich = 3.14 * (ban_kinh ** 2)

print("Dien tich hinh tron la:", dien_tich)
